dojo.provide("dojox.html.tests.performance.module");
if(dojo.isBrowser){
	dojo.require("dojox.html.tests.performance.format");
}


