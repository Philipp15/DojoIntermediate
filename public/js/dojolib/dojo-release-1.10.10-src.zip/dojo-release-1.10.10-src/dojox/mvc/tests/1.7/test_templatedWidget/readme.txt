1. This directory in dojox/mvc/test/templatedWidget is used to test the exprchar which is need for a custom templated widget. 
2. test_mvc_widget_template show how to use exprchar in a template for a widget to avoid a problem with ${..} error in repeat data binding.
3. Use test_mvc_widget.html to see the results.
