define([
	"dojox/treemap/tests/Store",
], 1);
