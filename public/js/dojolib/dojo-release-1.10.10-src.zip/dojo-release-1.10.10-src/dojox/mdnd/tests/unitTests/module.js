dojo.provide("dojox.mdnd.tests.unitTests.module");

try{
	dojo.require('dojox.mdnd.tests.unitTests.areaManager.module');
	dojo.require('dojox.mdnd.tests.unitTests.dropMode.module');
	dojo.require('dojox.mdnd.tests.unitTests.dropIndicator.module');
}catch(e){
	doh.debug(e);
}
