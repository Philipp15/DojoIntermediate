define(["./html/_base"], function (html) {
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/html modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return html;
});