// AMD-ID "dojox/math"
define(["dojo", "dojox", "dojox/math/_base"], function(dojo, dojox, math) {
	dojo.getObject("math", true, dojox);

	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/math modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/

	return dojox.math;
});
