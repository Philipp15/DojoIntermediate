dojo.provide("dojox.string.tests.string");

try{
	dojo.require("dojox.string.tests.Builder");
	dojo.require("dojox.string.tests.sprintf");
	dojo.require("dojox.string.tests.BidiComplex");
} catch(e){ }
