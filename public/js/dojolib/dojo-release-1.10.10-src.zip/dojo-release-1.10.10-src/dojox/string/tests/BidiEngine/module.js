dojo.provide("dojox.string.tests.BidiEngine.module");

try{
   	dojo.require("dojox.string.tests.BidiEngine.BidiEngineTest");
   	
   	dojo.require("dojox.string.tests.BidiEngine.BidiEngineTestLayouts");

}catch(e){
     doh.debug(e);
}