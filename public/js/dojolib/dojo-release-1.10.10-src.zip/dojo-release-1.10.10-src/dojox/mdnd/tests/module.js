dojo.provide("dojox.mdnd.tests.module");

try{
	dojo.require("dojox.mdnd.tests.unitTests.module");
	dojo.require("dojox.mdnd.tests.robot.module");
}catch(e){
	doh.debug(e);
}
